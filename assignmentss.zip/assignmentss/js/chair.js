

const activePage  = window.location.pathname;
const navLinks = document.querySelectorAll('nav a'). forEach (link => {

   if (link.href.includes(`${activePage}`)){
        link.classList.add('active');
        
    }
})

 
$(function(){
    $('.single-box').on('mouseenter', function(){
      $(this).children('.buy-btn').addClass("actives");
    })


    $('.single-box').on('mouseleave', function(){
      $(this).children('.buy-btn').removeClass("actives");
    })

  })


let secondrow = document.querySelector(".secondrow");
secondrow.style.display = "none";
let isShow = false;

function showHide() {

    if (isShow) {

        secondrow.style.display = "none";
        isShow = false;

    } else {

        secondrow.style.display = "block";
        isShow = true;
    }

    

}

